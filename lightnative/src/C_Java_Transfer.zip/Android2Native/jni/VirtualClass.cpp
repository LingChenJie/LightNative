#include "VirtualClass.h"



VirtualClass:: ~VirtualClass(){
}

ClassA:: ~ClassA(){
}

int main(){
	//VirtualClass * virtualClass = new VirtualClass();
	
	VirtualClass * classA = new ClassA();
	classA->fun1();
	return 0;
}

