#include"common.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <android/log.h>
#include <jni.h>
#include <assert.h>
#include <poll.h>
#include <android/looper.h>

#define TAG "JniUtils"
#define LOGE(TAG,...) __android_log_print(ANDROID_LOG_INFO,TAG,__VA_ARGS__)
static const char* const kClassPathName = "com/pax/object2struct/JniUtils";

//dump info
static void dumpCalssAInfo(ClassA_ *classA){
	LOGE(TAG, "+++  	Start dumpClassAInfo    +++\n");
	LOGE(TAG, "+++  	mArrayChar[0] : %d		+++\n",	classA->mArrayChar[0]);
	LOGE(TAG, "+++  	mArrayChar[1] : %d		+++\n",	classA->mArrayChar[1]);
	LOGE(TAG, "+++  	mArrayChar[2] : %d		+++\n",	classA->mArrayChar[2]);
	LOGE(TAG, "+++  	mArrayChar[3] : %d		+++\n",	classA->mArrayChar[3]);
	LOGE(TAG, "+++		mChar 		  : %d		+++\n", classA->mChar);
	LOGE(TAG, "+++		mShort 		  : %d		+++\n", classA->mShort);
	LOGE(TAG, "+++		End dumpClassAInfo		+++\n");
	
}

static int  getClassAInfo(ClassA_ * classA){
	classA->mArrayChar[0] = 0;
	classA->mArrayChar[1] = 1;
	classA->mArrayChar[2] = 2;
	classA->mArrayChar[3] = 3;

	classA->mChar = 4;
	classA->mShort = 100;
	return 0;
}

/*
 * Class:     com_pax_object2struct_JniUtils
 * Method:    getClassA
 * Signature: ([B)I
 */
JNIEXPORT jint JNICALL Java_com_pax_object2struct_JniUtils_getClassA
  (JNIEnv * env, jobject obj, jbyteArray byteArray)
{
	LOGE(TAG,"Java_com_pax_object2struct_JniUtils_getClassA");
	if(byteArray == NULL)
		return -1;

	jbyte *p_ClassA = NULL;
	p_ClassA = env->GetByteArrayElements(byteArray, 0);
	dumpCalssAInfo((ClassA_ *)p_ClassA);
	getClassAInfo((ClassA_ *)p_ClassA);
	dumpCalssAInfo((ClassA_ *)p_ClassA);
	env->ReleaseByteArrayElements(byteArray, p_ClassA, 0);
	return 0;
}


// Dalvik VM type signatures
static JNINativeMethod gMethods[] = {
	{ "getClassA", "([B)I",(void*) Java_com_pax_object2struct_JniUtils_getClassA},
};



//ע�ắ��
int register_native_interface(JNIEnv *env){
	jclass clazz;

	clazz = env->FindClass(kClassPathName);

	if (clazz == NULL)
	    return JNI_FALSE;

	if (env->RegisterNatives(clazz, gMethods, sizeof(gMethods) / sizeof(gMethods[0])) < 0){
	        return JNI_FALSE;
	 }

    return JNI_TRUE;
}

jint JNI_OnLoad(JavaVM * vm, void * reserved){
	JNIEnv * env = NULL;
	jint result = -1;

	if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
	    LOGE(TAG, "ERROR: GetEnv failed\n");
	    goto bail;
	}
	assert(env != NULL);


	if (register_native_interface(env) < 0) {
	    LOGE(TAG,"ERROR: native registration failed\n");
	    goto bail;
	}

	result = JNI_VERSION_1_4;
	bail:
	return result;
}

void JNI_OnUnload(JavaVM* vm, void* reserved){
	LOGE(TAG, "JNI_OnUnload called\n");
}


