#ifndef _COMMON_H
#define _COMMON_H

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <android/log.h>
#include <jni.h>


//Must be byte aligned
typedef struct{
	unsigned char mArrayChar[4];
	unsigned short mShort;
	unsigned char mChar;
}ClassA_;




//��Ӧ�com.pax.object2struct.JavaBean������
typedef struct{
	bool 		boolValue;   //boolean
	char 		charValue;	 //char 
	double 		doubleValue; //double
	int         intValue;	//int
	char        arrayValue[4]; //byte[]
	int 		double_dimen_array[2][2]; // int[][]
	const char * stringValue;
	const char * message; // String	
}JNI_JavaBean;



//��Ӧcom.pax.object2struct.JavaBean$InnerClass����ͷ���
typedef struct{
	jclass clazz;
	jfieldID message;
	jmethodID constructor;
}InnerClass_t;

//��Ӧcom.pax.object2struct.JavaBean����ͷ���
typedef struct {
	jclass clazz;

	jfieldID boolValue;
	jfieldID charValue;
	jfieldID doubleValue;
	jfieldID intVaule;
	jfieldID byteArray;
	jfieldID double_dimen_array;
	jfieldID stringValue;
	jfieldID inner_message;

	jmethodID constructor;
	
}JavaBean_t;

#endif
