#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <android/log.h>
#include <jni.h>
#include <assert.h>
#include <cutils/sockets.h>
#include <utils/Log.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/un.h>


#define SOCKET_NAME "local_socket_server"
#define LOGE(TAG,...) if(1) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__);

#define TAG "LocalSocket"


static void* recever_thread_exe(void *arg)
{
	int receive_fd = *(int *)arg;
	int numbytes ;
    char buff[1024] = {0};
	while(1){
		//ѭ���ȴ�Socket�ͻ��˷�����Ϣ
		//__android_log_write(ANDROID_LOG_DEBUG,"FTM_JNI","Waiting for receive");
		LOGE(TAG,"Waiting for receive\n");
		if((numbytes = recv(receive_fd,buff,sizeof(buff),0))==-1){
			LOGE(TAG,"recv %d\n", errno);
			perror("recv");
			continue;
		}
		LOGE(TAG,"receive msg from client : %s\n", buff);
		//������Ϣ��ִ��Socket�ͻ���
		if(send(receive_fd,buff,strlen(buff),0)==-1)
		{
			perror("send\n");
			LOGE(TAG,"send error\n");
			close(receive_fd);
			exit(0);
		}	
		LOGE(TAG,"send to client msg : %s\n", buff);
    }
    
    close(receive_fd);
	return ((void *)0);

}


int main()
{
	int max_connect_number = 6;
	int listen_fd = -1;
	int receive_fd = -1;
	int result;
	
	struct sockaddr addr;
	socklen_t alen;
	alen = sizeof(addr);

	//��ȡinit.rc�������õ���Ϊlocal_socket_server��socket
	listen_fd = android_get_control_socket(SOCKET_NAME);
	if(listen_fd < 0)
	{
		LOGE(TAG,"Failed to get socket '" SOCKET_NAME "' errno:%d\n", errno); 
		exit(-1);
	}
	LOGE(TAG,"android_get_control_socket success\n");


	//��ʼ����local_socket_server����������������
	result = listen(listen_fd, max_connect_number);
	if(result < 0 )
	{
		perror("listen\n");
		LOGE(TAG,"listen error\n");
		exit(-1);
	}
	LOGE(TAG,"listen success\n");
	fcntl(listen_fd, F_SETFD, FD_CLOEXEC);
	for(;;)
	{
		//�ȴ�Socket�ͻ��˷�����������
		receive_fd= accept(listen_fd, &addr, &alen);
		LOGE(TAG,"Accept_fd %d\n",receive_fd);
		if (receive_fd < 0 ) {
			LOGE(TAG,"%d\n",errno);
			perror("accept error");
			exit(-1);
		}

		fcntl(receive_fd, F_SETFD, FD_CLOEXEC);
		pthread_t id;
		//ͨ��pthread�ⴴ���߳�
	    if(pthread_create(&id, NULL, recever_thread_exe, &receive_fd) )
	    {
	        LOGE(TAG,"rece thread create fail\n");
	    }
	}
	
	close(listen_fd);
	return 0;
}

