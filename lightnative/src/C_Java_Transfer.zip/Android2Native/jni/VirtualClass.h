#include<stdio.h>
using namespace std;

class VirtualClass{
	public:
		virtual void fun1() = 0;//���麯��

		virtual ~VirtualClass();
};



class ClassA : public VirtualClass{
	public:
		void fun1(){
			printf("The is ClassA fun1\n");
		};

		virtual ~ClassA();
		
};



