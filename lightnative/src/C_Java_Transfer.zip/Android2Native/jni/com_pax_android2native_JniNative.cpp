#include "com_pax_android2native_JniNative.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <android/log.h>
#include <jni.h>
#include <assert.h>
#include <poll.h>
#include <utils/threads.h>
#include <utils/RefBase.h>
#include "NativeCode.h"
#include <utils/Looper.h>
#include <android/looper.h>
#include "MainStreamThread.h"



//ʹ��Android��
using namespace android;

#define TAG "JniNative"
#define LOGE(TAG,...) __android_log_print(ANDROID_LOG_INFO,TAG,__VA_ARGS__)

struct fields_t {
	jfieldID context;
	jmethodID notifyNativeCall;
};

static fields_t fields;
static NativeCode* mCode = NULL;

static const char* const kClassPathName = "com/pax/android2native/JniNative";
static bool initNativeCode(JNIEnv *env, jobject obj, jobject messageQueue);
static sp<MainStreamThread> getMainStreamThread(JNIEnv *env, jobject thiz);
static sp<MainStreamThread> setMainStreamThread(JNIEnv *env, jobject thiz, sp<MainStreamThread> &mt);


JNIEXPORT void JNICALL Java_com_pax_android2native_JniNative_nativeInit
  (JNIEnv * env, jobject object , jobject messageQueue){
	LOGE(TAG, "init called, pid=%d uid=%d gid=%d pthread_id=%d\n", getpid(), geteuid(), getegid(), pthread_self());
	if(mCode != NULL){
		delete mCode;
		mCode = NULL;
	}
    if(!initNativeCode(env, object, messageQueue)){
		return ;
	}

	char context[256] = "MainStreamThread";
	sp<MainStreamThread> mt = new MainStreamThread(context);
	mt->setNativeCode(mCode);
	setMainStreamThread(env, object, mt);

	//�����߳�
	mt->run(context, PRIORITY_DEFAULT);
	
	return;
}





static bool read_work(int fd, NativeWork* outWork) {
    int res = read(fd, outWork, sizeof(NativeWork));
    // no need to worry about EINTR, poll loop will just come back again.
    if (res == sizeof(NativeWork)) return true;

    if (res < 0) 
		//ALOGW("Failed reading work fd: %s", strerror(errno));
		LOGE(TAG,"Failed reading work fd: %s\n", strerror(errno));
    else 
		//ALOGW("Truncated reading work fd: %d", res);
		LOGE(TAG,"Truncated reading work fd: %d\n", res);
    return false;
}


/*
 * Callback for handling native events on the application's main thread.
 */
static int mainWorkCallback(int fd, int events, void* data){
	NativeCode * code = (NativeCode *) data;
	
    if ((events & POLLIN) == 0) {
        return 1;
    }

	NativeWork work;
	//��ȡ�ܵ���ص�����
	if (!read_work(code->mainWorkRead, &work)) {
        return 1;
    }

	switch(work.cmd){
		case CMD_NOTIFY_NATIVE_CALLBACK:{
			const char *data	= (char *)work.obj;
			jstring string 		= code->env->NewStringUTF(data);
			//ALOGW("-------CMD_NOTIFY_CUREENT_WRITER_FILE_PATH----%s----",data);
			LOGE(TAG,"------ CMD_NOTIFY_NATIVE_CALLBACK %s ------\n",data);
            code->env->CallVoidMethod(code->clazz, fields.notifyNativeCall, string);
            code->messageQueue->raiseAndClearException(code->env, "notifyNativeCall");
            delete []data;	
			break;
		}
			
		 default:
			break;
	}	
	
	
	return 1;
}


static bool initNativeCode(JNIEnv *env, jobject obj, jobject messageQueue){
	if(NULL == mCode){
		mCode = new NativeCode();
		mCode->messageQueue =  android_os_MessageQueue_getMessageQueue(env, messageQueue);
		if(mCode->messageQueue == NULL){
			LOGE(TAG,"Unable to retrieve native MessageQueue\n");
			delete mCode;
			return false;
		}
		//�����ܵ�
		int msgpipe[2];
		if(pipe(msgpipe)){
			LOGE(TAG,"Unable to  create pipe: %s\n", strerror(errno));
			delete mCode;
			return false;
		}

		mCode->mainWorkRead	     = msgpipe[0];
		mCode->mainWorkWrite	 = msgpipe[1];
		int result = fcntl(mCode->mainWorkRead, F_SETFL, O_NONBLOCK);
        result = fcntl(mCode->mainWorkWrite, F_SETFL, O_NONBLOCK);
        mCode->messageQueue->getLooper()->addFd(
			mCode->mainWorkRead, 0, ALOOPER_EVENT_INPUT, mainWorkCallback, mCode);
		mCode->env = env;
		mCode->clazz = env->NewGlobalRef(obj);

	}

	return true;
}



static sp<MainStreamThread> setMainStreamThread(JNIEnv *env, jobject thiz, sp<MainStreamThread> &mt){
    sp<MainStreamThread> old = (MainStreamThread*)env->GetIntField(thiz, fields.context);

    if (mt.get()) {
        mt->incStrong(thiz);
    }

    if (old != 0) {
    	//ALOGW("decStrong");
    	LOGE(TAG,"decStrong\n");
        old->decStrong(thiz);
    }

    env->SetIntField(thiz, fields.context, (int)mt.get());
    return old;
}

static sp<MainStreamThread> getMainStreamThread(JNIEnv *env, jobject thiz){

	MainStreamThread* const p = (MainStreamThread*)env->GetIntField(thiz, fields.context);
    return sp<MainStreamThread>(p);
}



// Dalvik VM type signatures
static JNINativeMethod gMethods[] = {
	{ "nativeInit", "(Landroid/os/MessageQueue;)V",(void*) Java_com_pax_android2native_JniNative_nativeInit },
};

#define GET_METHOD_ID(var, clazz, methodName, fieldDescriptor) \
		var = env->GetMethodID(clazz, methodName, fieldDescriptor); \
		LOG_FATAL_IF(!var, "Unable to find method " methodName);

//ע�ắ��
int register_native_interface(JNIEnv *env){
	jclass clazz;

	clazz = env->FindClass(kClassPathName);

	if (clazz == NULL)
	    return JNI_FALSE;

	if (env->RegisterNatives(clazz, gMethods, sizeof(gMethods) / sizeof(gMethods[0])) < 0){
	        return JNI_FALSE;
	 }

	GET_METHOD_ID(fields.notifyNativeCall, clazz, "notifyNativeCall", "(Ljava/lang/String;)V");

	//��java��mNativeFieId������jni��
	fields.context = env->GetFieldID(clazz, "mNativeFieId", "I");
    LOG_FATAL_IF(!fields.context, "Unable to find method mNativeFieId");

    return JNI_TRUE;
}

jint JNI_OnLoad(JavaVM * vm, void * reserved){
	JNIEnv * env = NULL;
	jint result = -1;

	if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
	    LOGE(TAG, "ERROR: GetEnv failed\n");
	    goto bail;
	}
	assert(env != NULL);


	if (register_native_interface(env) < 0) {
	    LOGE(TAG,"ERROR: native registration failed\n");
	    goto bail;
	}

	result = JNI_VERSION_1_4;
	bail:
	return result;
}

void JNI_OnUnload(JavaVM* vm, void* reserved){
	LOGE(TAG, "JNI_OnUnload called\n");
}




