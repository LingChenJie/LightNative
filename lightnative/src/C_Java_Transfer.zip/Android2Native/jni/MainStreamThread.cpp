#define TAG "MainStreamThread"

#include <utils/Log.h>
#include <stdio.h>
#include <jni.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <utils/threads.h>
#include "MainStreamThread.h"
#include <android/log.h>
#include "NativeCode.h"
#define LOGE(TAG,...) __android_log_print(ANDROID_LOG_INFO,TAG,__VA_ARGS__)

using namespace android;

void MainStreamThread::write_work(int fd, int32_t cmd, int32_t arg1, int32_t arg2, const void *data) {
	NativeWork work;
    work.cmd 	= cmd;
    work.arg1 	= arg1;
    work.arg2	= arg2;
    work.obj	= data;

    LOGE(TAG,"write_work: cmd=%d\n", cmd);

restart:
    int res = write(fd, &work, sizeof(work));
    if (res < 0 && errno == EINTR) {
        goto restart;
    }

    if (res == sizeof(work)) return;

    if (res < 0) 
		LOGE(TAG,"Failed writing to work fd: %s\n", strerror(errno));
    else 
		LOGE(TAG,"Truncated writing to work fd: %d\n", res);
}

void MainStreamThread::notifyNativeCall(const char *data){	
	LOGE(TAG, "init called, pid=%d uid=%d gid=%d pthread_id=%d\n", getpid(), geteuid(), getegid(), pthread_self());	
	char *mData;
    int len 	= strlen(data) + 1;
    mData 		= new char[len];
    strcpy(mData, data);

	write_work(mNativeCode->mainWorkWrite, CMD_NOTIFY_NATIVE_CALLBACK, 0, 0, (void *)mData);
}


MainStreamThread::MainStreamThread(const char * clientName):
	Thread(false){
	LOGE(TAG,"The current thread Name : %s\n", clientName);
}


MainStreamThread::~ MainStreamThread(){
	LOGE(TAG,"enter MainStreamThread::~ MainStreamThread\n");	
}

void MainStreamThread::onFirstRef(){
	LOGE(TAG,"enter MainStreamThread::onFirstRef\n");
}


status_t MainStreamThread::readToRun(){
	LOGE(TAG,"enter MainStreamThread::readToRun\n");
	status_t err = NO_ERROR;

	notifyNativeCall("MainStreamThread::readToRun");
	return err;
}


bool MainStreamThread::threadLoop(){
    status_t err = NO_ERROR;
	char context[256] = "Hello Java, Im from Native";
	notifyNativeCall(context);
	
	//������һ��
	return false;
}

