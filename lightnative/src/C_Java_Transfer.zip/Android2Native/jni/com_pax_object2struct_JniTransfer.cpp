#include"common.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <android/log.h>
#include <jni.h>
#include <assert.h>
#include <poll.h>




#define TAG "JniTransfer"
#define LOGE(TAG,...)__android_log_print(ANDROID_LOG_INFO,TAG,__VA_ARGS__)
static const char* const kClassPathName = "com/pax/object2struct/JniTransfer";


static JavaBean_t javaBean_t;
static InnerClass_t innerClass_t;
#define ARRAY_LEN(x) ((int) (sizeof(x) / sizeof((x)[0])))


static int dump_JavaBean_Info(JNI_JavaBean * javaBean){
	int i =0;
	int lenght = 0;

	LOGE(TAG, "+++ dump javaBean info start +++\n");

	LOGE(TAG, "+++ 		boolValue : %d 		+++\n", javaBean->boolValue);
	LOGE(TAG, "+++ 		charValue : %c 		+++\n", javaBean->charValue);
	LOGE(TAG, "+++ 		doubleVaule : %lf 	+++\n", javaBean->doubleValue);
	LOGE(TAG, "+++ 		intValue : %d		+++\n", javaBean->intValue);

	lenght = ARRAY_LEN(javaBean->arrayValue);
	for(i = 0; i < lenght; i++)
	{
		LOGE(TAG, "+++      byte[%d] : %d		+++\n", i, javaBean->arrayValue[i]);
	}

	for(i =0 ; i <2; i++){
		for(int j = 0; j <2; j++)
		{
			LOGE(TAG, "+++      byte[%d] : %d		+++\n", i, javaBean->arrayValue[i]);
			LOGE(TAG, "+++      double[%d][%d]: %d  +++\n", i, j, javaBean->double_dimen_array[i][j]);
		}
	}

	LOGE(TAG, "+++		stringValue : %s	+++\n", javaBean->stringValue);
	LOGE(TAG, "+++		inner_message : %s	+++\n", javaBean->message);
	
	LOGE(TAG, "+++ dump javaBean info end   +++\n");
}

static int find_class(JNIEnv * env, const char *className, jclass * classOut)
{
	jclass clazz = env->FindClass(className);
	if(clazz == NULL)
	{
		LOGE(TAG,"Can't find %s\n", className);
		return -1;
	}
	*classOut = (jclass) env->NewGlobalRef(clazz); // ��������½�һ��ȫ�ֵ�����
	return 0;
	
}

static int get_field(JNIEnv * env, jclass clazz, const char *name, const char *sig, jfieldID * field_out)
{
    jfieldID filed = env->GetFieldID(clazz, name, sig);
    if (filed == NULL) {
        LOGE(TAG, "Can't find. filed name: %s, sig: %s", name, sig);
        return -1;
    }
    *field_out = filed;
    return 0;

}

static void register_inner_class(JNIEnv * env)
{
	int ret = find_class(env, "com/pax/object2struct/JavaBean$InnerClass", &innerClass_t.clazz);
	if(ret != 0)
	{
		LOGE(TAG,"register_inner_class failed, please check you code!\n");
		return;
	}

	jclass inner_clazz = innerClass_t.clazz;
	// ��ȡ���췽��    
	innerClass_t.constructor = env->GetMethodID(inner_clazz, "<init>", "()V");   
	// ��ȡ��Ա    
	get_field(env, inner_clazz, "mMessage", "Ljava/lang/String;", &innerClass_t.message);

}

static void register_javaBean_class(JNIEnv * env)
{
	int ret = find_class(env, "com/pax/object2struct/JavaBean", &javaBean_t.clazz);
	if(ret != 0)
	{
		LOGE(TAG,"register_JavaBean_class failed, please check you code!\n");
		return;
	}


	jclass javaBean_clazz = javaBean_t.clazz;

	//��Jni�л�ȡ���췽��
	javaBean_t.constructor = env->GetMethodID(javaBean_clazz, "<init>", "()V");
	//��ȡ��Ա����
	//Signature: (ZCDI[B[[ILjava/lang/String;)V
	get_field(env, javaBean_clazz, "boolValue", "Z", &javaBean_t.boolValue);
	get_field(env, javaBean_clazz, "charValue", "C", &javaBean_t.charValue);
	get_field(env, javaBean_clazz, "doubleValue", "D", &javaBean_t.doubleValue);
	get_field(env, javaBean_clazz, "intValue", "I", &javaBean_t.intVaule);
	get_field(env, javaBean_clazz, "array", "[B", &javaBean_t.byteArray);
	get_field(env, javaBean_clazz, "mDoubleDimenArray", "[[I", &javaBean_t.double_dimen_array);
	get_field(env, javaBean_clazz, "stringValue", "Ljava/lang/String;", &javaBean_t.stringValue);
	get_field(env, javaBean_clazz, "mInnerClass", "Lcom/pax/object2struct/JavaBean$InnerClass;", &javaBean_t.inner_message);
}	

static void register_classes(JNIEnv* env)
{
	register_javaBean_class(env);
	register_inner_class(env);
}


/**
	c struct use jni transfer to java class
**/
static jobject javaBean_c_2_java(JNIEnv *env , JNI_JavaBean * jni_JavaBean)
{
	if(jni_JavaBean == NULL)
	{
		LOGE(TAG,"javaBean_c_2_java failed, jni_JavaBean is NULL\n");
		return NULL;
	}
	LOGE(TAG,"javaBean_c_2_java\n");


	LOGE(TAG,"innerObject\n");
	//1.create InnerClass class
	jobject innerObject = env->NewObject(innerClass_t.clazz, innerClass_t.constructor);
	jstring message = env->NewStringUTF(jni_JavaBean->message);
	env->SetObjectField(innerObject, innerClass_t.message, message);

	LOGE(TAG,"javaBeanObject\n");
	//2.create JavaBean class
	jobject javaBeanObject = env->NewObject(javaBean_t.clazz, javaBean_t.constructor);

	
	//set boolValue
	env->SetBooleanField(javaBeanObject, javaBean_t.boolValue, jni_JavaBean->boolValue);

	LOGE(TAG,"set charValue\n");
	//set charValue
	env->SetCharField(javaBeanObject, javaBean_t.charValue, jni_JavaBean->charValue);

	
	LOGE(TAG,"set doubleVaule\n");
	//set doubleVaule
	env->SetDoubleField(javaBeanObject, javaBean_t.doubleValue, jni_JavaBean->doubleValue);

	LOGE(TAG,"set intValue\n");
	//set intValue
	env->SetIntField(javaBeanObject, javaBean_t.intVaule, jni_JavaBean->intValue);

	LOGE(TAG,"set StringValue\n");
	//set StringValue
	jstring stringValue = env->NewStringUTF(jni_JavaBean->stringValue);
	env->SetObjectField(javaBeanObject, javaBean_t.stringValue, stringValue);

	LOGE(TAG,"set byte[] array\n");
	//set byte[] array
	jsize length = ARRAY_LEN(jni_JavaBean->arrayValue);
	LOGE(TAG,"The byteArray len : %d\n", length);
	jbyteArray byteArray = env->NewByteArray(length);
	env->SetByteArrayRegion(byteArray, 0, length, (jbyte *)jni_JavaBean->arrayValue);
	env->SetObjectField(javaBeanObject, javaBean_t.byteArray, byteArray);


	LOGE(TAG,"set double dimen int array\n");
	//set double dimen int array
	//���ö�ά�����ʱ����ҪҪһ���ļ�����
	length = ARRAY_LEN(jni_JavaBean->double_dimen_array);
	LOGE(TAG,"The double_dimen_array : %d\n", length);
	jclass clazz  = env->FindClass("[I");//һά�������
	jobjectArray double_int_array = env->NewObjectArray(length, clazz, NULL);


	
	for(int i = 0; i < length; i++)
	{
		jsize sub_len = ARRAY_LEN(jni_JavaBean->double_dimen_array[i]);
		LOGE(TAG,"The sub[%d] len: %d\n", i, sub_len);
		jintArray intArray = env->NewIntArray(sub_len);
		env->SetIntArrayRegion(intArray, 0, sub_len, jni_JavaBean->double_dimen_array[i]);
		env->SetObjectArrayElement(double_int_array, i, intArray);
	}
	env->SetObjectField(javaBeanObject, javaBean_t.double_dimen_array, double_int_array);

	//set innerClass 
	env->SetObjectField(javaBeanObject, javaBean_t.inner_message, innerObject);

	return javaBeanObject;
	
}


/**
	java class  use jni transfer to c struct
**/

static void javaBean_java_2_c(JNIEnv *env , jobject javaBean_in, JNI_JavaBean * jni_JavaBean_out)
{
	if(javaBean_in == NULL)
	{
		LOGE(TAG,"javaBean_in is NULL, please check you input or code!\n");
		return;
	}

	LOGE(TAG,"Start javaBean_java_2_c fun\n");


	//get boolValue
	jni_JavaBean_out->boolValue = env->GetBooleanField(javaBean_in, javaBean_t.boolValue);

	//get charValue
	jni_JavaBean_out->charValue = env->GetCharField(javaBean_in, javaBean_t.charValue);

	//get doubleValue
	jni_JavaBean_out->doubleValue = env->GetDoubleField(javaBean_in, javaBean_t.doubleValue);

	//get intValue
	jni_JavaBean_out->intValue = env->GetIntField(javaBean_in, javaBean_t.intVaule);


	//get byte array
	jbyteArray byteArray = (jbyteArray)env->GetObjectField(javaBean_in, javaBean_t.byteArray);
	jbyte * byte_data = env->GetByteArrayElements(byteArray, 0);
	jsize length = env->GetArrayLength(byteArray);
	LOGE(TAG,"The byteArray len : %d\n", length);
	//copy data
	memcpy(jni_JavaBean_out->arrayValue, byte_data, length * sizeof(jbyte));


	//get double dimen int array
	jobjectArray objectArray = (jobjectArray)env->GetObjectField(javaBean_in, javaBean_t.double_dimen_array);
	length = env->GetArrayLength(objectArray);
	LOGE(TAG,"doublemin int array len : %d\n", length);
	for(int i = 0; i < length; i++)
	{
		jintArray intArray = (jintArray)env->GetObjectArrayElement(objectArray, i);
		jint * sub_int = env->GetIntArrayElements(intArray, 0);
		jsize sub_len = env->GetArrayLength(intArray); // ��ȡ���� 	   
		LOGE(TAG,"sub_len: %d", sub_len);		
		memcpy(jni_JavaBean_out->double_dimen_array[i], sub_int, sub_len * sizeof(jint));		
		env->ReleaseIntArrayElements(intArray, sub_int, 0);
	}

	
	//get stringValue
	LOGE(TAG,"get StringValue\n");
	jstring stringValue = (jstring)env->GetObjectField(javaBean_in, javaBean_t.stringValue);
	jni_JavaBean_out->stringValue = env->GetStringUTFChars(stringValue, 0);
	
	

	//get inner class data
	LOGE(TAG,"get inner class data\n");
	jobject inner_object = env->GetObjectField(javaBean_in, javaBean_t.inner_message);
	jstring message = (jstring)env->GetObjectField(inner_object, innerClass_t.message);
	jni_JavaBean_out->message = env->GetStringUTFChars(message, 0);
}


/*
 * Class:     com_pax_object2struct_JniTransfer
 * Method:    getJavaBeanFromNative
 * Signature: ()Lcom/pax/object2struct/JavaBean;
 */
JNIEXPORT jobject JNICALL Java_com_pax_object2struct_JniTransfer_getJavaBeanFromNative
  (JNIEnv * env, jclass clazz)
{
	 JNI_JavaBean javaBean= {
			true,
			'c',
			1,
			2,
			{1, 2, 3, 4},
			{
				{5,6},
				{7,8}
			},
			"Im StringValue",
			"Im message",
		};


		
	dump_JavaBean_Info(&javaBean);
	jobject obj = javaBean_c_2_java(env, &javaBean);
	return obj;
}

/*
 * Class:     com_pax_object2struct_JniTransfer
 * Method:    transferJavaBeanToNative
 * Signature: (Lcom/pax/object2struct/JavaBean;)V
 */
JNIEXPORT void JNICALL Java_com_pax_object2struct_JniTransfer_transferJavaBeanToNative
  (JNIEnv * env, jclass clazz, jobject object)
{
	JNI_JavaBean   jni_JavaBean;
	javaBean_java_2_c(env, object, &jni_JavaBean);	
	dump_JavaBean_Info(&jni_JavaBean);
}



static JNINativeMethod gMethods[] = {
	{"getJavaBeanFromNative", "()Lcom/pax/object2struct/JavaBean;",(void*)Java_com_pax_object2struct_JniTransfer_getJavaBeanFromNative },
	{"transferJavaBeanToNative", "(Lcom/pax/object2struct/JavaBean;)V",(void*)Java_com_pax_object2struct_JniTransfer_transferJavaBeanToNative },
};	

static int register_native_interface(JNIEnv * env){
	jclass clazz;
	clazz = env->FindClass(kClassPathName);

	if(clazz == NULL)
		return JNI_FALSE;

	if (env->RegisterNatives(clazz, gMethods, sizeof(gMethods) / sizeof(gMethods[0])) < 0){
	        return JNI_FALSE;
	 }

	
	return JNI_TRUE;
}


jint JNI_OnLoad(JavaVM * vm, void * reserved){
	JNIEnv * env = NULL;
	jint result = -1;

	if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
	    LOGE(TAG, "ERROR: GetEnv failed\n");
	    goto bail;
	}
	assert(env != NULL);
	if (register_native_interface(env) < 0) {
	    LOGE(TAG,"ERROR: native registration failed\n");
	    goto bail;
	}
	register_classes(env);

	result = JNI_VERSION_1_4;
	bail:
	return result;
	
}

