#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <utils/threads.h>
#include <utils/RefBase.h>
#include <android_os_MessageQueue.h>
#include <android_runtime/AndroidRuntime.h>


namespace android {

struct  NativeCode {
	NativeCode() {
		mainWorkRead = mainWorkWrite = -1;
    }

    ~NativeCode(){
        if (env != NULL && clazz != NULL) {
            env->DeleteGlobalRef(clazz);
        }
        if (messageQueue != NULL && mainWorkRead >= 0) {
            messageQueue->getLooper()->removeFd(mainWorkRead);
        }
        if (mainWorkRead >= 0) close(mainWorkRead);
        if (mainWorkWrite >= 0) close(mainWorkWrite);
    }
    JNIEnv* env;
    jobject clazz;
    int mainWorkRead;
    int mainWorkWrite;
    sp<MessageQueue> messageQueue;
};

struct NativeWork {
    int32_t cmd;
    int32_t arg1;
    int32_t arg2;
    const void *obj;
};

enum {
    CMD_NOTIFY_NATIVE_CALLBACK = 1,
};
};
