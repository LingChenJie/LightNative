#pragma once
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include "NativeCode.h"
using namespace android;

class MainStreamThread : public Thread{
public:
	MainStreamThread(const char *clientName);
	virtual ~MainStreamThread();
	virtual void onFirstRef();
	virtual status_t 	readToRun();
	virtual bool 		threadLoop();
	//�麯�����Բ�ʵ��
	virtual void 		requestExit(){};
	void 	 setNativeCode(NativeCode* nativeCode){mNativeCode = nativeCode;}
	void 	 write_work(int fd, int32_t cmd, int32_t arg1, int32_t arg2, const void *data);
	//֪ͨJava�������Ϣ
	void 	 notifyNativeCall(const char *data);
	
private:
	NativeCode * mNativeCode;
	
};