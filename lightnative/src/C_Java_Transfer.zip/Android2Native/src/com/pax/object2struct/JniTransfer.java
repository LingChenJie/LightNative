package com.pax.object2struct;

public class JniTransfer {

    // 将C/C++结构体转为Java类
    public static native JavaBean getJavaBeanFromNative();

    //将Java对象转换成C/C++结构体
    public static native void transferJavaBeanToNative(JavaBean javaBean);

    // 加载jni库
    static {
        System.loadLibrary("java2native-transfer");
    }
}
