package com.pax.object2struct;

public class JavaBean {
    public boolean boolValue = false; // boolean类型
    public char charValue  = 'A'; // char类型
    public double doubleValue = 100; // double类型
    public int intValue = 100; // 整形
    public byte[] array = {0, 1, 2, 3}; // byte数组

    public int[][] mDoubleDimenArray = {
            {10,10},
            {20,20}
    }; // 二维数组
    public String stringValue = "Hello!";
    public InnerClass mInnerClass = new InnerClass(); // 静态内部类

    static class InnerClass {
        public String mMessage = "Im from Java!";// 字符串

        @Override
        public String toString() {
            return "InnerClass [mMessage=" + mMessage + "]";
        }

    }

    @Override
    public String toString() {
        return "JavaBean [boolValue=" + boolValue + ", charValue=" + charValue
                + ", doubleValue=" + doubleValue + ", intValue=" + intValue
                + ", array=" + array.toString() + ", mDoubleDimenArray="
                + mDoubleDimenArray.toString() + ", stringValue=" + stringValue
                + ", mInnerClass=" + mInnerClass + "]";
    }

}
