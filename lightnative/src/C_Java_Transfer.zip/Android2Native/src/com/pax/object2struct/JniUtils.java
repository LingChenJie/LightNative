package com.pax.object2struct;

public class JniUtils {

    public static native int getClassA(byte[] data);
    
    
    static{
        System.loadLibrary("jni_struct2class");
    }

}
