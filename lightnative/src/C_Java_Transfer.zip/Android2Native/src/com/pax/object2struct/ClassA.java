package com.pax.object2struct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public class ClassA {

    byte[] byteAarray = new byte[4];

    short mShort;
    byte mByte;

    public ClassA() {
        this.mByte = 10;
        this.mShort = 20;
        for (int i = 0; i < byteAarray.length; i++) {
            byteAarray[i] = (byte) (i * 10);
        }
    }

    /**
     * Converting object into byte array.
     * 
     * @return byte array of ClassA
     */

    public byte[] serialToBuffer() {
        ByteBuffer mByteBuffer = ByteBuffer.allocate(1024);
        mByteBuffer.clear();
        mByteBuffer.order(ByteOrder.LITTLE_ENDIAN);

        mByteBuffer.put(byteAarray);
        mByteBuffer.putShort((short) mShort);
        mByteBuffer.put(mByte);

        mByteBuffer.flip();
        byte[] ret = new byte[mByteBuffer.limit()];
        mByteBuffer.get(ret);
        return ret;
    }

    /**
     * Converting byte array into object.
     * 
     * @param bb
     *            byte array of ClassA
     */
    public void serialFromBuffer(byte[] bb) {
        ByteBuffer mByteBuffer = ByteBuffer.wrap(bb);
        mByteBuffer.order(ByteOrder.LITTLE_ENDIAN);

        mByteBuffer.get(this.byteAarray);
        this.mShort = (short) mByteBuffer.getShort();
        this.mByte = mByteBuffer.get();

    }

    @Override
    public String toString() {
        return "ClassA [byteAarray=" + Arrays.toString(byteAarray) + ", mByte="
                + mByte + ", mShort=" + mShort + "]";
    }

}
