package com.pax.android2native;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class TcpClientManager {

    private static TcpClientManager mTcpClientConnector;
    private Socket mClient;
    private ConnectListener mListener;
    private Thread mConnectThread;
    private static final int HANDMESSAGE = 0;

    public interface ConnectListener {
        void onReceiveData(String data);
    }

    public void setOnConnectListener(ConnectListener listener) {
        this.mListener = listener;
    }

    public static TcpClientManager getInstance() {
        if (mTcpClientConnector == null)
            mTcpClientConnector = new TcpClientManager();
        return mTcpClientConnector;
    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
            case HANDMESSAGE:
                if (mListener != null) {
                    mListener.onReceiveData(msg.getData().getString("data"));
                }
                break;
            }
        }
    };

    public void createConnect(final String mSerIP, final int mSerPort) {
        if (mConnectThread == null) {
            mConnectThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    connect(mSerIP, mSerPort);
                }
            });
            mConnectThread.start();
        }
    }

    /**
     * 与服务端进行连接
     * 
     * @throws IOException
     */
    private void connect(String mSerIP, int mSerPort) {
        if (mClient == null) {
            try {
                mClient = new Socket(mSerIP, mSerPort);
            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (mClient.isConnected()) {
            Message message = Message.obtain();
            message.what = HANDMESSAGE;
            Bundle bundle = new Bundle();
            bundle.putString("data", "Connect Server success\n");
            message.setData(bundle);
            mHandler.sendMessage(message);
        }

    }

    /**
     * 发送数据
     * 
     * @param data
     *            需要发送的内容
     */
    public void send(String data) {

        try {
            OutputStream outputStream = mClient.getOutputStream();
            outputStream.write(data.getBytes());

            InputStream inputStream;
            inputStream = mClient.getInputStream();
            if (inputStream == null) {
                Log.e("TAG", "inputStream error");
                return;
            }
            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = inputStream.read(buffer)) != -1) {
                String recedata = new String(buffer, 0, len);
                Message message = Message.obtain();
                message.what = HANDMESSAGE;
                Bundle bundle = new Bundle();
                bundle.putString("data", recedata);
                message.setData(bundle);
                mHandler.sendMessage(message);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * 断开连接
     * 
     * @throws IOException
     */
    public void disconnect() throws IOException {
        if (mClient != null) {
            mClient.close();
            mClient = null;
        }
    }
}
