package com.pax.android2native;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class LocalSocketClientManager {
    private final String SOCKET_NAME = "local_socket_server";
    private LocalSocket client;
    private LocalSocketAddress address;
    private boolean isConnected = false;
    private int connetTime = 1;
    private static final int HANDMESSAGE = 0;
    private static final String TAG = "LocalSocketClientManager";
    private ConnectListener mListener;

    private static LocalSocketClientManager mLocalSocketClientManager = null;

    public interface ConnectListener {
        void onReceiveData(String data);
    }

    public void setOnConnectListener(ConnectListener listener) {
        this.mListener = listener;
    }

    public static LocalSocketClientManager getInstance() {
        if (mLocalSocketClientManager == null) {
            synchronized (LocalSocketClientManager.class) {
                if (mLocalSocketClientManager == null) {
                    mLocalSocketClientManager = new LocalSocketClientManager();
                }
            }
        }
        return mLocalSocketClientManager;
    }

    public void connectLocalSocketServer() {
        client = new LocalSocket();
        address = new LocalSocketAddress(SOCKET_NAME,
                LocalSocketAddress.Namespace.RESERVED);
        new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                while (!isConnected && connetTime <= 10) {
                    try {
                        Thread.sleep(1000);
                        Log.i(TAG, "Try to connect socket;ConnectTime:"
                                + connetTime);
                        client.connect(address);
                        isConnected = true;
                        if (client.isConnected()) {
                            sendMesssage("Connect Server success\n");
                        }
                    } catch (Exception e) {
                        connetTime++;
                        isConnected = false;
                        Log.i(TAG, "Connect fail");
                    }
                }

            }
        }).start();
    }

    public void send(String data) {
        try {
            OutputStream outputStream = client.getOutputStream();
            outputStream.write(data.getBytes());

            InputStream inputStream;
            inputStream = client.getInputStream();
            if (inputStream == null) {
                Log.e("TAG", "inputStream error");
                return;
            }
            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = inputStream.read(buffer)) != -1) {
                String recedata = new String(buffer, 0, len);
                sendMesssage(recedata);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
            case HANDMESSAGE:
                if (mListener != null) {
                    mListener.onReceiveData(msg.getData().getString("data"));
                }
                break;
            }
        }
    };

    private void sendMesssage(String msg) {
        Message message = Message.obtain();
        message.what = HANDMESSAGE;
        Bundle bundle = new Bundle();
        bundle.putString("data", msg);
        message.setData(bundle);
        mHandler.sendMessage(message);
    }

    /**
     * 关闭Socket
     */
    public void disconnect() {
        try {
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
