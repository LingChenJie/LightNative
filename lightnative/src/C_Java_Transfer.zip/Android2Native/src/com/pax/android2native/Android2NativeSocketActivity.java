package com.pax.android2native;

import java.io.IOException;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

public class Android2NativeSocketActivity extends Activity {

    private EditText edtTxt_Addr;
    private EditText edtTxt_Port;
    private ToggleButton tglBtn;
    private TextView tv_Msg;
    private EditText edtTxt_Data;
    private Button btn_Send;

    private TcpClientManager mTcpClientManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socket);

        InitWidgets();
        mTcpClientManager = TcpClientManager.getInstance(); // 获取connector实例
        tglBtn.setOnCheckedChangeListener(new TglBtnCheckedChangeEvents());
        btn_Send.setOnClickListener(new ButtonClickEvent());

    }

    /***
     * 控件初始化
     */
    private void InitWidgets() {
        edtTxt_Addr = (EditText) findViewById(R.id.edtTxt_Addr);
        edtTxt_Port = (EditText) findViewById(R.id.edtTxt_Port);
        tglBtn = (ToggleButton) findViewById(R.id.tglBtn);
        tv_Msg = (TextView) findViewById(R.id.tv_Msg);
        edtTxt_Data = (EditText) findViewById(R.id.edtTxt_Data);
        btn_Send = (Button) findViewById(R.id.btn_Send);
    }

    class TglBtnCheckedChangeEvents implements
            ToggleButton.OnCheckedChangeListener {

        @Override
        public void onCheckedChanged(CompoundButton btnView, boolean isChecked) {
            if (btnView == tglBtn) {
                if (isChecked == true) {
                    new Thread(new Runnable() {

                        @Override
                        public void run() {
                            // TODO Auto-generated method stub
                            // 连接Tcp服务器端
                            // connector.createConnect("172.16.46.41",8888);
                            // //调试使用
                            mTcpClientManager.createConnect(edtTxt_Addr
                                    .getText().toString(), Integer
                                    .parseInt(edtTxt_Port.getText().toString()));
                            mTcpClientManager
                                    .setOnConnectListener(new TcpClientManager.ConnectListener() {
                                        @Override
                                        public void onReceiveData(
                                                final String data) {
                                            // Received Data,do somethings.
                                            Android2NativeSocketActivity.this
                                                    .runOnUiThread(new Runnable() {

                                                        @Override
                                                        public void run() {
                                                            // TODO
                                                            // Auto-generated
                                                            // method stub
                                                            tv_Msg.append("Server:"
                                                                    + data
                                                                    + "\n");
                                                        }
                                                    });

                                        }
                                    });
                        }
                    }).start();

                } else {
                    try { // 断开与服务器的连接
                        mTcpClientManager.disconnect();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    class ButtonClickEvent implements View.OnClickListener {
        public void onClick(View v) {
            if (v == btn_Send) {
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        mTcpClientManager
                                .send(edtTxt_Data.getText().toString());
                    }
                }).start();

                tv_Msg.append("Client:" + edtTxt_Data.getText().toString()
                        + "\n");
            }
        }
    }
}
