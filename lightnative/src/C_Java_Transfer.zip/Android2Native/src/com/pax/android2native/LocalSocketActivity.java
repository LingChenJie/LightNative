package com.pax.android2native;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

public class LocalSocketActivity extends Activity {

    private EditText edtTxt_Addr;
    private EditText edtTxt_Port;
    private ToggleButton tglBtn;
    private TextView tv_Msg;
    private EditText edtTxt_Data;
    private Button btn_Send;

    private LocalSocketClientManager mLocalSocketClientManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socket);

        InitWidgets();
        mLocalSocketClientManager = LocalSocketClientManager.getInstance(); // 获取connector实例
        tglBtn.setOnCheckedChangeListener(new TglBtnCheckedChangeEvents());
        btn_Send.setOnClickListener(new ButtonClickEvent());

    }

    /***
     * 控件初始化
     */
    private void InitWidgets() {
        edtTxt_Addr = (EditText) findViewById(R.id.edtTxt_Addr);
        edtTxt_Port = (EditText) findViewById(R.id.edtTxt_Port);
        tglBtn = (ToggleButton) findViewById(R.id.tglBtn);
        tv_Msg = (TextView) findViewById(R.id.tv_Msg);
        edtTxt_Data = (EditText) findViewById(R.id.edtTxt_Data);
        btn_Send = (Button) findViewById(R.id.btn_Send);
        
        LinearLayout view1 = (LinearLayout)findViewById(R.id.view1);
        view1.setVisibility(View.GONE);
        
        LinearLayout view2 = (LinearLayout)findViewById(R.id.view2);
        view2.setVisibility(View.GONE);
        edtTxt_Data.clearFocus();
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(edtTxt_Data.getWindowToken(),0);
    }

    class TglBtnCheckedChangeEvents implements
            ToggleButton.OnCheckedChangeListener {

        @Override
        public void onCheckedChanged(CompoundButton btnView, boolean isChecked) {
            if (btnView == tglBtn) {
                if (isChecked == true) {
                    new Thread(new Runnable() {

                        @Override
                        public void run() {
                            // TODO Auto-generated method stub
                            // 连接远程服务
                            mLocalSocketClientManager
                                    .connectLocalSocketServer();
                            mLocalSocketClientManager
                                    .setOnConnectListener(new LocalSocketClientManager.ConnectListener() {
                                        @Override
                                        public void onReceiveData(
                                                final String data) {
                                            // Received Data,do somethings.
                                            LocalSocketActivity.this
                                                    .runOnUiThread(new Runnable() {

                                                        @Override
                                                        public void run() {
                                                            // TODO
                                                            // Auto-generated
                                                            // method stub
                                                            tv_Msg.append("Server:"
                                                                    + data
                                                                    + "\n");
                                                        }
                                                    });

                                        }
                                    });
                        }
                    }).start();

                } else {
                    mLocalSocketClientManager.disconnect();
                }
            }
        }
    }

    class ButtonClickEvent implements View.OnClickListener {
        public void onClick(View v) {
            if (v == btn_Send) {
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        mLocalSocketClientManager.send(edtTxt_Data.getText()
                                .toString());
                    }
                }).start();

                tv_Msg.append("Client:" + edtTxt_Data.getText().toString()
                        + "\n");
            }
        }
    }
}
