package com.pax.android2native;

import java.util.ArrayList;
import java.util.List;

import android.os.MessageQueue;

public class JniNative {


    // native methods call
    private int mNativeFieId = 0;
    

    private native void nativeInit(MessageQueue mqueue);

    public void NativeInit(MessageQueue mqueue) {
        nativeInit(mqueue);
    }

    private List<JniNativeListerner> mJniNativeListerners = new ArrayList<JniNativeListerner>();

    public interface JniNativeListerner {
        public void notifyNativeCall(String msg);

    }

    public void setNativeListen(JniNativeListerner mJniNativeListerner) {
        mJniNativeListerners.add(mJniNativeListerner);
    }

    public void removeNativeListen(JniNativeListerner mJniNativeListerner) {
        mJniNativeListerners.remove(mJniNativeListerner);
    }

    //Native method callback
    public void notifyNativeCall(String msg) {
        for (JniNativeListerner lis : mJniNativeListerners) {
            lis.notifyNativeCall(msg);
        }
    }
    
    static {
        System.loadLibrary("Native_jni");
    }
}
