package com.pax.android2native;

import com.pax.android2native.JniNative.JniNativeListerner;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class JniActivity extends Activity {

    private Button jni_btn;
    private JniManager mJniManager;

    private static final int STOPTHREAD = 0;
    private static final String TAG =  "JniActivity";
    
    
    private JniNative mJniNative;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jni_activity);
        jni_btn = (Button) findViewById(R.id.btn_1);
        mJniManager = new JniManager();
        mJniNative = new JniNative();

        jni_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Log.e(TAG,"The current process id :  " + android.os.Process.myPid());
                Log.e(TAG, "The current thread id :  " + Thread.currentThread().getId());
                mJniManager.openJni();
                mJniManager.nativeThreadStart();
                
                handler.sendEmptyMessageDelayed(STOPTHREAD, 1000 * 10);
            }
        });
        
        
        
        Button jni_btn2 = (Button)findViewById(R.id.btn_2);
        jni_btn2.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                mJniNative.NativeInit(handler.getLooper().myQueue());
                mJniNative.setNativeListen(new JniNativeListerner() {
                    
                    @Override
                    public void notifyNativeCall(String msg) {
                        // TODO Auto-generated method stub
                        Log.e(TAG,"The current process id :  " + android.os.Process.myPid());
                        Log.e(TAG, "The current thread id :  " + Thread.currentThread().getId());
                        Log.e(TAG,"notifyNativeCall : " + msg);
                    }
                });
            }
        });
    }

    Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            super.handleMessage(msg);
            switch (msg.what) {
            case STOPTHREAD:
                mJniManager.nativeThreadStop();
                break;

            default:
                break;
            }
        }

    };

}
