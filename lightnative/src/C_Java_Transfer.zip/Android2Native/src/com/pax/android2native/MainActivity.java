package com.pax.android2native;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button socket_btn = (Button) findViewById(R.id.btn_1);
        socket_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(Android2NativeSocketActivity.class);
            }
        });

        Button jni_btn = (Button) findViewById(R.id.btn_2);
        jni_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(JniActivity.class);
            }
        });

        Button local_socket = (Button) findViewById(R.id.btn_3);
        local_socket.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(LocalSocketActivity.class);
            }
        });

        Button jni_two_socket = (Button) findViewById(R.id.btn_4);
        jni_two_socket.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(JniActivity.class);
            }
        });

        Button struct2class = (Button) findViewById(R.id.btn_5);
        struct2class.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                startActivity(TransferActivity.class);
            }
        });

    }

    private void startActivity(Class<?> clss) {
        Intent intent = new Intent(MainActivity.this, clss);
        startActivity(intent);
    }

}
