package com.pax.android2native;

import android.util.Log;

public class JniManager {

    private static final String TAG = JniManager.class.getSimpleName();

    public native void openJni();//native方法

    public native void nativeThreadStart();//native方法

    public native void nativeThreadStop();//native方法

    public void callByJni(int count) {//供jni回调
        Log.e(TAG, "From jni count : " + count);
    }

    static {
        System.loadLibrary("jni");//加载jni库
    }
}
