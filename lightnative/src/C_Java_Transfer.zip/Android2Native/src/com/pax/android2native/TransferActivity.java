package com.pax.android2native;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.pax.object2struct.ClassA;
import com.pax.object2struct.JavaBean;
import com.pax.object2struct.JniTransfer;
import com.pax.object2struct.JniUtils;

public class TransferActivity extends Activity {

    @Override
    protected void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);

        setContentView(R.layout.jni_activity);

        Button bt1 = (Button) findViewById(R.id.btn_1);
        bt1.setText("C结构体和Java对象相互转换方式一");
        bt1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                ClassA mClassA = new ClassA();
                Log.e("JniUtils", "The ClassA : " + mClassA);
                byte[] data = mClassA.serialToBuffer();
                JniUtils.getClassA(data);
                mClassA.serialFromBuffer(data);
                Log.e("JniUtils", "The ClassA : " + mClassA);
            }
        });

        Button bt2 = (Button) findViewById(R.id.btn_2);
        bt2.setText("C结构体和Java对象相互转换方式二");
        bt2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub
                        Log.e("JniTransfer","getJavaBeanFromC");
                        getJavaBeanFromC();
                        Log.e("JniTransfer","\n");
                        Log.e("JniTransfer","javaBeanToStruct");
                        javaBeanToStruct();
                    }
                }).start();
            }
        });

    }

    private void getJavaBeanFromC() {
        JavaBean javaBean = JniTransfer.getJavaBeanFromNative();
        Log.d("JniTransfer", javaBean.toString());
    }

    private void javaBeanToStruct() {
        JavaBean javaBean = new JavaBean();
        JniTransfer.transferJavaBeanToNative(javaBean);
    }

}
