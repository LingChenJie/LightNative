/** Automatically generated file. DO NOT MODIFY */
package com.pax.android2native;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}